<?php

/**
 * CountryRepositoryBlueprint.php - Interface file
 *
 * This file is part of the Country component.
 *-----------------------------------------------------------------------------*/

namespace App\Yantrana\Support\Country\Blueprints;

interface CountryRepositoryBlueprint
{
}
