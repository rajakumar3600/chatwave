<?php
/**
* AuthEngineInterface.php - Interface file
*
* This file is part of the Auth component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Auth\Interfaces;

interface AuthEngineInterface
{
}
