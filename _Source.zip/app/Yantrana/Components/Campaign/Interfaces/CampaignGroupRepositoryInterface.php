<?php
/**
* CampaignGroupRepositoryInterface.php - Interface file
*
* This file is part of the Campaign component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Campaign\Interfaces;

interface CampaignGroupRepositoryInterface
{
}
