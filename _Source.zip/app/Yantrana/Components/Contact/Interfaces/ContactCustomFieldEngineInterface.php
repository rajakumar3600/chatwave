<?php
/**
* ContactCustomFieldEngineInterface.php - Interface file
*
* This file is part of the ContactCustomField component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Contact\Interfaces;

interface ContactCustomFieldEngineInterface
{
}